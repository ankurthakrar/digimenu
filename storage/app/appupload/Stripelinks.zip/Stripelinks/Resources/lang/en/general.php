<?php

return [

    'name'              => 'Stripelinks',
    'description'       => 'This is my awesome module',

];